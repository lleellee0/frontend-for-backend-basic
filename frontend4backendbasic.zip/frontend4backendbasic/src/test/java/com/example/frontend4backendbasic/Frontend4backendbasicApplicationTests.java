package com.example.frontend4backendbasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Frontend4backendbasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
