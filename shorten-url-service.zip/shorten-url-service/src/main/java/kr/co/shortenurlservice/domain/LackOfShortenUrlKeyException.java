package kr.co.shortenurlservice.domain;

public class LackOfShortenUrlKeyException extends RuntimeException {
}
