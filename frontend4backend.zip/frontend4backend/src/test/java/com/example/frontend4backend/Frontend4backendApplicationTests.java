package com.example.frontend4backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Frontend4backendApplicationTests {

	@Test
	void contextLoads() {
	}

}
